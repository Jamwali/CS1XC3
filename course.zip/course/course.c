/**
 * @file course.c
 * @author Ishaan Jamwal (jamwali@mcmaster.ca)
 * @brief Implementations for the course library.
 * @version 1
 * @date 2022-04-12
 *
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>


/**
 *
 *
 * @brief Adds a specific student to the array of students enrolled in a certain course.
 *
 * @param course A course in which the student is enrolled
 * @param student A student who is enrolled in a course.
 */

 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    //If this is the sole student, it allocates heap space.
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    //If the array of students has already been defined, reallocate space for the new student.
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // Student should be added to the end of the array of enrolled students.
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Used to print course.
 * 
 * @param course - This is the Course to print.
 */


void print_course(Course* course)
{
  //Prints information saved in the course.
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //Iterates through an array of enrolled students, printing each name.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Returns the student with the highest course average.
 * 
 * @param course - Course to look through.
 * @return Student*
 */


Student* top_student(Course* course)
{
  //When there are no students enrolled in the course, do nothing.
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  //Begin with the highest-scoring student.
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
 //runs over the array and rewrites the highest value till the end
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }
  //provides a reference to the student with the highest average.
  return student;
}

/**
 * @brief Returns an array of all passing students in a specific course and rewrites the number of passing students value.
 * 
 * @param course - Course to look through.
 * @param total_passing - Total number of students who passed.
 * @return Student*
 */


Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  //calculates the number of students that pass
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  //provides adequate heap space for the amount of passing students
  passing = calloc(count, sizeof(Student));

  int j = 0;
  //runs over the array of students again, adding students to the array if they pass. 
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }
//overwrites the value of total passing in a roundabout way.
  *total_passing = count;
//The array of passing students is returned.
  return passing;
}
/**
 * @file course.h
 * @author Ishaan Jamwal (jamwali@mcmaster.ca)
 * @brief A header file containing the definitions of structs and functions. Implemented in courses.c
 * @version 1
 * @date 2022-04-12
 *
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief A course structure that contains the name, code, total number of students, and a list of students.
 * struct contains: 
 * - array of students 
 * - course name 
 * - number of students
 * - code
 * @warning The course name cannot be more than 100 characters long, and the course code cannot be more than 50 characters long.
 */

typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);



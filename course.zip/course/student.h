/**
 * @file student.h
 * @author Ishaan Jamwal (jamwali@mcmaster.ca)
 * @brief A header file containing the definitions of structs and functions. Implemented in students.c
 * @version 1
 * @date 2022-04-12
 *
 */

/**
 * @brief A student is represented by a struct.
 * struct contains:
 * - student id
 * - array of grades
 * - first name of student
 * - number of grades
 * - last name of student 
 * @warning First and last names cannot include more than 50 characters.
 * @warning The student id must be at least 11 characters long.
 */

typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
